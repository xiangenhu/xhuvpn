# AI Perception Survey — CLAUDE.md

## Project Overview
A scenario-based public opinion diagnostic that maps users' **functional beliefs about AI** through personalized, adaptive scenarios. Built in React + Vite, calling the Anthropic API directly from the browser.

## Core Architecture
```
src/
  main.jsx           Entry point
  App.jsx            Phase-state machine: intro → profile → personalizing → survey → loading → result
  data.js            Static data: ARCHETYPES, PROFILE_STEPS, FALLBACK_SCENARIOS, profileToString()
  api.js             Anthropic API calls: generateScenarios(), generateAnalysis(), computeArchetype()
  styles.js          Design tokens (S), COLORS, FONTS, GLOBAL_CSS string
  components/
    Screens.jsx      IntroScreen, ProfileScreen, PersonalizingScreen, LoadingScreen
    SurveyResult.jsx SurveyScreen, ResultScreen
```

## Design Decisions
- **All 5 scenarios are AI-generated** from user profile at survey start (not fixed seeds)
- **API key resolution**: `import.meta.env.VITE_ANTHROPIC_API_KEY` → `window.__ANTHROPIC_API_KEY__`
- **Graceful fallback**: if API fails at any stage, FALLBACK_SCENARIOS or canned analysis text is used
- **No routing library**: phase-state machine in App.jsx (intro/profile/personalizing/survey/loading/result)
- **No CSS framework**: all styles are inline JS objects from `styles.js`
- **Fonts**: Playfair Display (serif, scenarios), DM Mono (labels/data), DM Sans (body)
- **Aesthetic**: dark editorial (#080b14 bg, #fbbf24 amber accent, grid overlay, floating particles)

## The 5 Archetypes
| Key | Label | Color |
|---|---|---|
| tool | The Instrumentalist | #6ee7b7 |
| pragmatist | The Pragmatist | #fbbf24 |
| collaborator | The Collaborator | #818cf8 |
| delegator | The Delegator | #f87171 |
| transcendent | The Transcendentalist | #e879f9 |

## Profile Dimensions Collected
- domain (8 options: tech, health, education, law, creative, business, government, other)
- age (genz, millennial, genx, boomer)
- experience (none, casual, regular, power)
- primary_use (productivity, creative, learning, decision)
- region (north_america, europe, east_asia, south_asia, other)
- concern (control, jobs, truth, connection, opportunity, nothing)

## API Prompts
### Scenario generation (api.js → generateScenarios)
- Model: claude-sonnet-4-20250514
- Returns: JSON array of 5 scenario objects
- Each scenario: { domain, icon, setup, question, options[4] }
- Each option: { label, value(tool|assist|partner|authority), weight{archetype_key: 1-3} }

### Analysis generation (api.js → generateAnalysis)
- Model: claude-sonnet-4-20250514
- Returns: 4-sentence plain text analysis
- Sentence structure: S1=revealed belief, S2=consistency/tension, S3=practical implication, S4=falsifying condition

## Environment Setup
```bash
cp .env.example .env.local
# Add VITE_ANTHROPIC_API_KEY=sk-ant-...
npm install
npm run dev
```

## Current Status (v0.1)
- [x] Phase machine: all 6 phases implemented
- [x] Profile collection: 3 steps, 6 dimensions, tile UI
- [x] Scenario generation: full API pipeline + fallback
- [x] Archetype scoring: weighted accumulation across 5 types
- [x] Analysis generation: personalized 4-sentence profile
- [x] Result screen: spectrum bars, strengths/tensions, lineage, choice replay

## Planned Features (Claude Code tasks)
- [ ] Response persistence: store anonymous results in localStorage + optional Supabase backend
- [ ] Aggregate view: "N% of [domain] professionals share your archetype" (requires backend)
- [ ] Divergence detector: flag when profile signals contradict choices (e.g. AI builder → pure tool stance)
- [ ] Bilingual mode: Chinese translation with culturally adapted scenario prompts
- [ ] Share card: generate a styled PNG/SVG of archetype result
- [ ] Admin dashboard: visualise aggregate archetype distributions by domain/region/generation
- [ ] Scenario bank: curate and version high-quality personalized scenarios by domain
- [ ] A/B test: compare scenario quality between model versions

## Coding Conventions
- Functional React components only (no class components)
- Props typed via JSDoc comments (no TypeScript yet)
- Styles as plain JS objects (no CSS modules, no Tailwind)
- API errors always caught and logged; fallback content always available
- No external state management (useState/useRef only)

## Key Invariants
- `answers.length === scenarios_answered` at all times
- `computeArchetype([])` returns scores all 0 and top='tool' (safe default)
- Profile is always complete before `generateScenarios` is called
- `FALLBACK_SCENARIOS` always has exactly 5 items matching scenario schema
