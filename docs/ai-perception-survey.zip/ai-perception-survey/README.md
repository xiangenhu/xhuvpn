# AI Perception Survey

> A scenario-based diagnostic that maps your functional belief about AI.  
> Five personalized scenarios. One objective archetype profile.

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Set up environment
cp .env.example .env.local
# Edit .env.local → add your Anthropic API key

# 3. Run dev server
npm run dev
# Opens at http://localhost:5173
```

## Project Structure

```
ai-perception-survey/
├── src/
│   ├── main.jsx              React entry point
│   ├── App.jsx               Phase-state machine (6 phases)
│   ├── data.js               Archetypes, profile steps, fallback scenarios
│   ├── api.js                Anthropic API: scenario gen + analysis
│   ├── styles.js             Design tokens + global CSS
│   └── components/
│       ├── Screens.jsx       Intro, Profile, Personalizing, Loading
│       └── SurveyResult.jsx  Survey + Result screens
├── CLAUDE.md                 Context file for Claude Code sessions
├── .env.example              API key template
└── vite.config.js
```

## Using Claude Code

This project is set up for Claude Code sessions. The `CLAUDE.md` file gives Claude
Code full project context so you can continue development naturally.

```bash
# Install Claude Code (native installer — no Node.js required)
# macOS/Linux:
curl -fsSL https://claude.ai/install.sh | sh

# Windows PowerShell:
# winget install Anthropic.ClaudeCode

# Navigate to project and start a session
cd ai-perception-survey
claude
```

Example Claude Code prompts to try:
- `"Add localStorage persistence so results survive page refresh"`
- `"Build a Supabase backend to aggregate anonymous archetype distributions"`
- `"Add a share card that generates a styled PNG of the archetype result"`
- `"Create a divergence detector that flags when profile contradicts choices"`
- `"Add Chinese language support with culturally adapted scenario prompts"`

## Tech Stack

- **React 18** + **Vite 5**
- **Anthropic claude-sonnet-4-20250514** for scenario generation and analysis
- Zero CSS frameworks — all styles are inline JS tokens
- No routing — phase-state machine in App.jsx

## API Key

Get a key at [console.anthropic.com/keys](https://console.anthropic.com/keys).  
Add to `.env.local` as `VITE_ANTHROPIC_API_KEY=sk-ant-...`

> Note: This calls the Anthropic API directly from the browser. For production,
> route calls through a server-side proxy to keep your key secret.
