import { useState, useEffect } from 'react'
import { useSurvey }           from './hooks/useSurvey.js'
import { PROFILE_STEPS }       from './data/archetypes.js'
import { S, GLOBAL_CSS }       from './styles.js'

// Screen components (split for readability)
import { IntroScreen }         from './components/IntroScreen.jsx'
import { ProfileScreen }       from './components/ProfileScreen.jsx'
import { SurveyScreen }        from './components/SurveyScreen.jsx'
import { ResultScreen }        from './components/ResultScreen.jsx'
import { LoadingScreen }       from './components/LoadingScreen.jsx'

export default function App() {
  const { state, startSession, selectOption, confirmAnswer, restart } = useSurvey()
  const [profileStep, setProfileStep] = useState(0)
  const [profile,     setProfile]     = useState({})
  const [particles,   setParticles]   = useState([])

  useEffect(() => {
    setParticles(Array.from({ length: 18 }, (_, i) => ({
      id: i, x: Math.random()*100, y: Math.random()*100,
      size: Math.random()*2.5+1, dur: Math.random()*22+14, delay: Math.random()*12,
    })))
  }, [])

  function isStepComplete(idx) {
    return PROFILE_STEPS[idx].fields.every(f => !f.required || profile[f.key])
  }

  function handleProfileNext() {
    if (profileStep < PROFILE_STEPS.length - 1) {
      setProfileStep(profileStep + 1)
    } else {
      startSession(profile)
    }
  }

  function handleRestart() {
    setProfileStep(0)
    setProfile({})
    restart()
  }

  const { phase } = state

  const isLoading = ['creating_session', 'loading_question', 'submitting_answer', 'completing'].includes(phase)

  return (
    <div style={S.root}>
      {/* Ambient particles */}
      <div style={S.particleField}>
        {particles.map(p => (
          <div key={p.id} style={{
            ...S.particle,
            left: `${p.x}%`, top: `${p.y}%`,
            width: p.size, height: p.size,
            animationDuration: `${p.dur}s`, animationDelay: `${p.delay}s`,
          }}/>
        ))}
      </div>
      <div style={S.grid}/>

      <div style={S.content}>
        {phase === 'idle' && (
          <IntroScreen onStart={() => setState && undefined /* triggers profile */}
            onStartInner={() => { /* App handles this via profileStep=0 */
              // The "Build my profile" button sets phase to 'profiling' via a local state flag.
              // We handle this with a simple local boolean below.
            }}
          />
        )}

        {/* Intro → show profile when user clicks start */}
        {phase === 'idle' && (
          <IntroScreen onStart={() => setProfile(p => ({ ...p, _started: true }))} />
        )}

        {profile._started && phase === 'idle' && (
          <ProfileScreen
            step={profileStep}
            totalSteps={PROFILE_STEPS.length}
            profile={profile}
            onChange={(k, v) => setProfile(p => ({ ...p, [k]: v }))}
            onNext={handleProfileNext}
            onBack={() => {
              if (profileStep > 0) {
                setProfileStep(profileStep - 1)
              } else {
                setProfile({})  // back to intro
              }
            }}
            isComplete={isStepComplete(profileStep)}
          />
        )}

        {isLoading && (
          <LoadingScreen
            phase={phase}
            questionIndex={state.questionIndex}
            profile={profile}
          />
        )}

        {phase === 'answering' && state.scenario && (
          <SurveyScreen
            scenario={state.scenario}
            questionIndex={state.questionIndex}
            totalQuestions={state.totalQuestions}
            selected={state.selected}
            onSelect={selectOption}
            onNext={confirmAnswer}
          />
        )}

        {phase === 'result' && state.result && (
          <ResultScreen
            result={state.result}
            answers={state.answers}
            profile={profile}
            onRestart={handleRestart}
          />
        )}

        {phase === 'error' && (
          <div style={{ ...S.col, alignItems: 'center', textAlign: 'center', maxWidth: 480 }}>
            <div style={{ fontSize: 32, marginBottom: 20 }}>⚠</div>
            <p style={{ fontFamily: "'DM Mono',monospace", fontSize: 11, color: '#f87171', letterSpacing: '.15em', marginBottom: 12 }}>ERROR</p>
            <p style={S.body}>{state.error}</p>
            <button className="cta" onClick={handleRestart} style={S.ctaBtn}>Start over →</button>
          </div>
        )}
      </div>

      <style>{GLOBAL_CSS}</style>
    </div>
  )
}
