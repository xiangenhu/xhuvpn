/**
 * useSurvey — central hook that drives the entire survey flow.
 *
 * State machine:
 *   idle → profiling → creating_session → loading_question →
 *   answering → submitting_answer → [loading_question | completing] →
 *   generating_result → result | error
 *
 * All server calls go through src/api.js — no LLM calls in the browser.
 */

import { useState, useCallback, useRef } from 'react'
import {
  createSession,
  getNextScenario,
  submitAnswer,
  completeSession,
} from '../api.js'

const INITIAL = {
  phase:         'idle',          // see state machine above
  sessionId:     null,
  profile:       null,
  scenario:      null,            // current scenario object
  questionIndex: 0,
  totalQuestions: 5,
  selected:      null,            // currently selected option
  answers:       [],              // { label, value, weight, scenarioIndex, domain }
  result:        null,            // { archetype, scores, aiAnalysis, archetypeData }
  error:         null,
}

export function useSurvey() {
  const [state, setState] = useState(INITIAL)
  const questionStartRef  = useRef(null)   // timestamp when scenario was shown

  const set = (patch) => setState(prev => ({ ...prev, ...patch }))

  // ── Submit profile → create session → load first question ─────────────────
  const startSession = useCallback(async (profile) => {
    set({ phase: 'creating_session', profile, error: null })
    try {
      const { sessionId } = await createSession(profile)
      set({ sessionId, phase: 'loading_question' })
      await loadQuestion(sessionId)
    } catch (err) {
      set({ phase: 'error', error: err.message })
    }
  }, [])

  // ── Load next scenario from server ────────────────────────────────────────
  const loadQuestion = useCallback(async (sid) => {
    set({ phase: 'loading_question', selected: null })
    try {
      const data = await getNextScenario(sid)
      if (data.done) {
        await finish(sid)
        return
      }
      questionStartRef.current = Date.now()
      set({
        phase:         'answering',
        scenario:      data.scenario,
        questionIndex: data.questionIndex,
        totalQuestions: data.totalQuestions || 5,
      })
    } catch (err) {
      set({ phase: 'error', error: err.message })
    }
  }, [])

  // ── User selects an option ────────────────────────────────────────────────
  const selectOption = useCallback((option) => {
    set({ selected: option })
  }, [])

  // ── User confirms selection → submit to server ────────────────────────────
  const confirmAnswer = useCallback(async () => {
    setState(prev => {
      if (!prev.selected || prev.phase !== 'answering') return prev
      return { ...prev, phase: 'submitting_answer' }
    })

    setState(prev => {
      if (prev.phase !== 'submitting_answer') return prev
      const { sessionId, selected, scenario, questionIndex } = prev
      const timeOnQuestionMs = questionStartRef.current
        ? Date.now() - questionStartRef.current
        : 0

      // Fire-and-forget + chain
      const answerPayload = {
        label:           selected.label,
        value:           selected.value,
        weight:          selected.weight,
        scenarioIndex:   questionIndex,
        timeOnQuestionMs,
      }

      submitAnswer(sessionId, answerPayload)
        .then(() => loadQuestion(sessionId))
        .catch(err => set({ phase: 'error', error: err.message }))

      return {
        ...prev,
        answers: [...prev.answers, { ...answerPayload, domain: scenario?.domain }],
        phase:   'loading_question',
        selected: null,
      }
    })
  }, [loadQuestion])

  // ── All questions answered → request analysis ─────────────────────────────
  const finish = useCallback(async (sid) => {
    set({ phase: 'completing' })
    try {
      const result = await completeSession(sid)
      set({ phase: 'result', result })
    } catch (err) {
      set({ phase: 'error', error: err.message })
    }
  }, [])

  // ── Restart ───────────────────────────────────────────────────────────────
  const restart = useCallback(() => {
    setState(INITIAL)
  }, [])

  return { state, startSession, selectOption, confirmAnswer, restart }
}
