/**
 * Frontend API Client
 * All calls go to /api/* (same-origin in production, proxied in dev).
 * No API keys in the browser — all LLM calls are server-side.
 */

const BASE = '/api'

async function request(method, path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json' },
    ...(body ? { body: JSON.stringify(body) } : {}),
  })
  const data = await res.json()
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`)
  return data
}

const get  = (path)       => request('GET',  path)
const post = (path, body) => request('POST', path, body)

// ── Sessions ────────────────────────────────────────────────────────────────

/** Create a new session and persist profile. Returns { sessionId, startedAt } */
export async function createSession(profile) {
  return post('/sessions', { profile })
}

/** Resume a session (for page refresh). Returns { sessionId, profile, state } */
export async function getSession(sessionId) {
  return get(`/sessions/${sessionId}`)
}

/** Get LLM usage for this session. Returns { records, total } */
export async function getSessionUsage(sessionId) {
  return get(`/sessions/${sessionId}/usage`)
}

// ── Survey ───────────────────────────────────────────────────────────────────

/**
 * Get the next scenario.
 * Returns { done, questionIndex, totalQuestions, scenario }
 * If done=true, call completeSession() next.
 */
export async function getNextScenario(sessionId) {
  return get(`/survey/${sessionId}/next`)
}

/**
 * Submit an answer. Returns { ok, questionIndex }
 * @param {string} sessionId
 * @param {{ label, value, weight, scenarioIndex, timeOnQuestionMs }} answer
 */
export async function submitAnswer(sessionId, answer) {
  return post(`/survey/${sessionId}/answer`, answer)
}

/**
 * Trigger analysis generation and mark session complete.
 * Returns { archetype, scores, aiAnalysis, archetypeData, sessionId }
 */
export async function completeSession(sessionId) {
  return post(`/survey/${sessionId}/complete`, {})
}

/** Retrieve a previously computed result. */
export async function getResult(sessionId) {
  return get(`/survey/${sessionId}/result`)
}
