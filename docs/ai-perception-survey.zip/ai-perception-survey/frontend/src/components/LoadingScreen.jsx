import { S } from '../styles.js'

const MESSAGES = {
  creating_session:  { label: 'BUILDING YOUR PROFILE', sub: 'Generating personalized scenarios for you—this takes a moment.' },
  loading_question:  { label: 'THINKING',              sub: 'Adapting next scenario based on your answers so far.' },
  submitting_answer: { label: 'RECORDING',             sub: '' },
  completing:        { label: 'ANALYSING YOUR STANCE', sub: 'Mapping your choices across domains, computing archetype alignment.' },
  personalizing:     { label: 'PERSONALIZING',         sub: 'Placing you in your domain and calibrating scenario complexity.' },
}

export function LoadingScreen({ phase, questionIndex, profile }) {
  const msg  = MESSAGES[phase] || { label: 'LOADING', sub: '' }
  const domainMap = { tech:'your technology world', health:'your clinical environment', education:'your research context', law:'your legal domain', creative:'your creative practice', business:'your business context', government:'your public-sector work', other:'your professional world' }

  return (
    <div style={{ ...S.col, alignItems: 'center', textAlign: 'center', maxWidth: 480 }}>
      <div style={{ fontSize: 44, color: '#fbbf24', animation: 'spin 2.2s linear infinite', marginBottom: 28 }}>◈</div>
      <p style={{ fontFamily: "'DM Mono',monospace", fontSize: 11, color: '#fbbf24', letterSpacing: '.18em', marginBottom: 14 }}>
        {msg.label}
      </p>
      {msg.sub && (
        <p style={{ fontSize: 14, color: '#6b7280', lineHeight: 1.65, maxWidth: 360 }}>
          {phase === 'creating_session' && profile?.domain
            ? `Placing you in ${domainMap[profile.domain] || 'your domain'}, calibrating for your experience level, surfacing your stated concern.`
            : msg.sub}
        </p>
      )}
      {phase === 'loading_question' && questionIndex > 0 && (
        <p style={{ fontFamily: "'DM Mono',monospace", fontSize: 10, color: '#374151', marginTop: 16 }}>
          Question {questionIndex + 1} · adapting to your responses
        </p>
      )}
    </div>
  )
}
