/**
 * Admin Routes  (prefix: /api/admin)
 * Protected by ADMIN_SECRET header.
 *
 * GET /api/admin/usage/daily/:date        — daily LLM cost summary
 * GET /api/admin/aggregates               — archetype distribution across all sessions
 * GET /api/admin/xapi/:sessionId          — all xAPI statements for a session (today)
 */

import { Router } from 'express'
import * as gcs   from '../services/gcs.js'

export const adminRouter = Router()

// Simple secret-header auth middleware
adminRouter.use((req, res, next) => {
  const secret = req.headers['x-admin-secret']
  if (!process.env.ADMIN_SECRET || secret !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' })
  }
  next()
})

// GET /api/admin/usage/daily/:date  (date = YYYY-MM-DD)
adminRouter.get('/usage/daily/:date', async (req, res) => {
  try {
    const totals = await gcs.getDailyUsage(req.params.date)
    if (!totals) return res.status(404).json({ error: 'No data for this date' })
    res.json(totals)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// GET /api/admin/aggregates
adminRouter.get('/aggregates', async (req, res) => {
  try {
    const agg = await gcs.getAggregates()
    res.json(agg)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// GET /api/admin/xapi/:sessionId?date=YYYY-MM-DD
adminRouter.get('/xapi/:sessionId', async (req, res) => {
  try {
    const date = req.query.date || new Date().toISOString().slice(0, 10)
    const stmts = await gcs.getSessionStatements(req.params.sessionId, date)
    res.json({ count: stmts.length, statements: stmts })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})
