/**
 * Survey Routes
 *
 * GET  /api/survey/:sessionId/next            — generate & return next scenario
 * POST /api/survey/:sessionId/answer          — submit answer, update state, emit xAPI
 * POST /api/survey/:sessionId/complete        — generate analysis, save result, emit xAPI completed
 * GET  /api/survey/:sessionId/result          — retrieve saved result
 */

import { Router }       from 'express'
import { z }            from 'zod'
import * as gcs         from '../services/gcs.js'
import * as xapi        from '../services/xapi.js'
import {
  generateNextScenario,
  generateAnalysis,
  computeScores,
  dominantArchetype,
  isTied,
  DEFAULT_QUESTION_COUNT,
  MAX_QUESTIONS,
}                       from '../services/adaptive.js'
import { ARCHETYPES }   from '../data/archetypes.js'

export const surveyRouter = Router()

const AnswerSchema = z.object({
  label:          z.string().min(1),
  value:          z.enum(['tool', 'assist', 'partner', 'authority']),
  weight:         z.record(z.number()),
  scenarioIndex:  z.number().int().min(0),
  timeOnQuestionMs: z.number().int().min(0).optional(),
})

// ── GET /api/survey/:sessionId/next ─────────────────────────────────────────
//
// Generates the next scenario on-demand.
// If the scenario already exists in GCS (user refreshed), returns the cached version.
//
surveyRouter.get('/:sessionId/next', async (req, res) => {
  const { sessionId } = req.params
  try {
    const [{ profile }, state] = await Promise.all([
      gcs.getProfile(sessionId),
      gcs.getState(sessionId),
    ])

    const qIndex = state.questionIndex

    // Determine if survey should continue
    const scores = computeScores(state.answers)
    const tied   = isTied(scores) && qIndex >= DEFAULT_QUESTION_COUNT
    const maxQ   = tied ? MAX_QUESTIONS : DEFAULT_QUESTION_COUNT

    if (qIndex >= maxQ) {
      return res.json({ done: true, questionIndex: qIndex })
    }

    // Return cached scenario if already generated (idempotent)
    let scenario
    try {
      scenario = await gcs.getScenario(sessionId, qIndex)
    } catch {
      // Not yet generated — call adaptive engine
      const priorScenarios = await Promise.all(
        state.answers.map((_, i) => gcs.getScenario(sessionId, i).catch(() => null))
      ).then(ss => ss.filter(Boolean))

      const { scenario: generated, usage } = await generateNextScenario({
        sessionId,
        profile,
        priorScenarios,
        priorAnswers: state.answers,
        questionIndex: qIndex,
      })
      scenario = generated

      // Persist scenario
      await gcs.saveScenario(sessionId, qIndex, scenario)

      // xAPI: scenario viewed — emit after generation
      await xapi.emit(xapi.stmtScenarioViewed(sessionId, scenario, qIndex))

      // xAPI: LLM accounting statement
      await xapi.emit(xapi.stmtLLMCall(sessionId, usage))
    }

    res.json({
      done:          false,
      questionIndex: qIndex,
      totalQuestions: DEFAULT_QUESTION_COUNT + (tied ? MAX_QUESTIONS - DEFAULT_QUESTION_COUNT : 0),
      scenario,
    })
  } catch (err) {
    console.error('[survey/next]', err)
    res.status(500).json({ error: err.message })
  }
})

// ── POST /api/survey/:sessionId/answer ──────────────────────────────────────
surveyRouter.post('/:sessionId/answer', async (req, res) => {
  const { sessionId } = req.params
  try {
    const answer = AnswerSchema.parse(req.body)
    const state  = await gcs.getState(sessionId)

    if (answer.scenarioIndex !== state.questionIndex) {
      return res.status(409).json({ error: 'Answer index mismatch — possible duplicate submission' })
    }

    // Append answer + advance index
    const newAnswers = [...state.answers, {
      label:     answer.label,
      value:     answer.value,
      weight:    answer.weight,
      answeredAt:new Date().toISOString(),
    }]

    const newState = {
      ...state,
      questionIndex: state.questionIndex + 1,
      answers:       newAnswers,
    }
    await gcs.saveState(sessionId, newState)

    // xAPI: answered statement
    const scenario = await gcs.getScenario(sessionId, answer.scenarioIndex).catch(() => ({ domain:'unknown', setup:'', question:'' }))
    await xapi.emit(xapi.stmtAnswered(sessionId, scenario, answer.scenarioIndex, answer, answer.timeOnQuestionMs || 0))

    res.json({ ok: true, questionIndex: newState.questionIndex })
  } catch (err) {
    if (err.name === 'ZodError') return res.status(400).json({ error: 'Invalid answer', details: err.errors })
    console.error('[survey/answer]', err)
    res.status(500).json({ error: err.message })
  }
})

// ── POST /api/survey/:sessionId/complete ────────────────────────────────────
surveyRouter.post('/:sessionId/complete', async (req, res) => {
  const { sessionId } = req.params
  try {
    const [{ profile }, state] = await Promise.all([
      gcs.getProfile(sessionId),
      gcs.getState(sessionId),
    ])

    if (state.answers.length === 0) {
      return res.status(400).json({ error: 'No answers recorded — cannot complete' })
    }

    // Load all scenarios for analysis context
    const scenarios = await Promise.all(
      state.answers.map((_, i) => gcs.getScenario(sessionId, i).catch(() => ({ domain: `Q${i+1}`, setup:'', question:'' })))
    )

    // Generate analysis
    const { analysis, archetype, scores, usage } = await generateAnalysis({
      sessionId,
      profile,
      scenarios,
      answers: state.answers,
    })

    const result = {
      archetype,
      scores,
      aiAnalysis: analysis,
      archetypeData: ARCHETYPES[archetype],
    }

    // Persist result + update aggregates
    await Promise.all([
      gcs.saveResult(sessionId, result),
      gcs.updateAggregates(result, profile),
    ])

    // xAPI: completed + LLM accounting
    const totalMs = state.startedAt
      ? Date.now() - new Date(state.startedAt).getTime()
      : 0
    await Promise.all([
      xapi.emit(xapi.stmtCompleted(sessionId, archetype, scores, analysis, totalMs)),
      xapi.emit(xapi.stmtLLMCall(sessionId, usage)),
    ])

    res.json({ ...result, sessionId })
  } catch (err) {
    console.error('[survey/complete]', err)
    res.status(500).json({ error: err.message })
  }
})

// ── GET /api/survey/:sessionId/result ───────────────────────────────────────
surveyRouter.get('/:sessionId/result', async (req, res) => {
  try {
    const result = await gcs.getResult(req.params.sessionId)
    res.json(result)
  } catch {
    res.status(404).json({ error: 'Result not found' })
  }
})
