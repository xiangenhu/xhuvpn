/**
 * Session Routes
 * POST /api/sessions              — create session, save profile, emit xAPI initialized
 * GET  /api/sessions/:id          — get session state (for resume)
 * GET  /api/sessions/:id/usage    — get LLM usage for this session
 */

import { Router }         from 'express'
import { v4 as uuidv4 }   from 'uuid'
import { z }              from 'zod'
import * as gcs           from '../services/gcs.js'
import * as xapi          from '../services/xapi.js'

export const sessionRouter = Router()

const ProfileSchema = z.object({
  domain:      z.enum(['tech','health','education','law','creative','business','government','other']),
  age:         z.enum(['genz','millennial','genx','boomer']),
  experience:  z.enum(['none','casual','regular','power']),
  primary_use: z.enum(['productivity','creative','learning','decision']),
  region:      z.enum(['north_america','europe','east_asia','south_asia','other']),
  concern:     z.enum(['control','jobs','truth','connection','opportunity','nothing']),
})

// ── POST /api/sessions ──────────────────────────────────────────────────────
sessionRouter.post('/', async (req, res) => {
  try {
    const profile   = ProfileSchema.parse(req.body.profile)
    const sessionId = uuidv4()
    const startedAt = new Date().toISOString()

    // Persist profile
    await gcs.saveProfile(sessionId, profile)

    // Initialise state
    await gcs.saveState(sessionId, {
      questionIndex: 0,
      answers:       [],
      startedAt,
    })

    // xAPI: survey initialized
    await xapi.emit(xapi.stmtInitialized(sessionId, profile))

    res.status(201).json({ sessionId, startedAt })
  } catch (err) {
    if (err.name === 'ZodError') return res.status(400).json({ error: 'Invalid profile', details: err.errors })
    console.error('[sessions POST]', err)
    res.status(500).json({ error: err.message })
  }
})

// ── GET /api/sessions/:id ───────────────────────────────────────────────────
sessionRouter.get('/:id', async (req, res) => {
  try {
    const { id } = req.params
    const [profile, state] = await Promise.all([gcs.getProfile(id), gcs.getState(id)])
    res.json({ sessionId: id, profile: profile.profile, state })
  } catch (err) {
    console.error('[sessions GET]', err)
    res.status(404).json({ error: 'Session not found' })
  }
})

// ── GET /api/sessions/:id/usage ─────────────────────────────────────────────
sessionRouter.get('/:id/usage', async (req, res) => {
  try {
    const records = await gcs.getSessionUsage(req.params.id)
    const total = records.reduce((acc, r) => ({
      calls:             acc.calls + 1,
      prompt_tokens:     acc.prompt_tokens + r.prompt_tokens,
      completion_tokens: acc.completion_tokens + r.completion_tokens,
      cost_usd:          acc.cost_usd + r.cost_usd,
    }), { calls: 0, prompt_tokens: 0, completion_tokens: 0, cost_usd: 0 })
    res.json({ sessionId: req.params.id, records, total })
  } catch (err) {
    console.error('[sessions/usage GET]', err)
    res.status(500).json({ error: err.message })
  }
})
