/**
 * Adaptive Engine
 *
 * All 5 (or N) scenarios are generated dynamically by the LLM.
 * Each generation uses the full context:
 *   - User profile (domain, generation, experience, use, region, concern)
 *   - All previous questions shown
 *   - All previous answers selected
 *   - Running archetype score vector
 *
 * Adaptive strategy per question index:
 *   Q0 — Anchor: user's own professional domain, low ambiguity
 *   Q1 — Stretch: adjacent domain, tests transfer of stance
 *   Q2 — Emotional: personal/social stakes, generationally framed
 *   Q3 — Civic: power/governance, regionally anchored; probes concern
 *   Q4 — Pressure: designed to maximally discriminate between top two archetypes
 *
 * After Q4, the engine can generate additional questions if scores are tied
 * (tiebreaker mode), up to MAX_QUESTIONS total.
 */

import { llmJSON } from './llm.js'
import { ARCHETYPES, profileToString } from '../data/archetypes.js'

export const DEFAULT_QUESTION_COUNT = 5
export const MAX_QUESTIONS          = 7   // tiebreaker ceiling

const STRATEGY = [
  { name: 'anchor',    instruction: "Set in the user's own professional domain. A realistic dilemma they would actually face. Medium stakes — not life-or-death, not trivial." },
  { name: 'stretch',   instruction: "Set in a domain adjacent to the user's work but one step outside their daily context. Tests whether their stance transfers across domains." },
  { name: 'emotional', instruction: "Personal/social stakes — grief, connection, identity, or relationships. Frame it through the lens of their generation. Probe the boundary between tool and companion." },
  { name: 'civic',     instruction: "Power, governance, or justice. Anchor to their region's specific political and regulatory context. Directly engage their stated concern." },
  { name: 'pressure',  instruction: "Designed to maximally discriminate between the user's top two archetype scores. Make the options as hard to choose between as possible. This is the decisive question." },
  { name: 'tiebreak1', instruction: "The user's scores are tied. Design a scenario that forces a clear choice between the two tied archetypes. Use a domain they haven't seen yet." },
  { name: 'tiebreak2', instruction: "Still tied. Use a deeply personal scenario with irreversible stakes to force a final resolution." },
]

const OPTION_VALUES = ['tool', 'assist', 'partner', 'authority']

// ─── Score utilities ────────────────────────────────────────────────────────

export function computeScores(answers) {
  const scores = { tool: 0, pragmatist: 0, collaborator: 0, delegator: 0, transcendent: 0 }
  for (const a of answers) {
    for (const [k, v] of Object.entries(a.weight || {})) {
      scores[k] = (scores[k] || 0) + v
    }
  }
  return scores
}

export function topTwo(scores) {
  return Object.entries(scores)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([k]) => k)
}

export function isTied(scores) {
  const sorted = Object.values(scores).sort((a, b) => b - a)
  return sorted[0] === sorted[1]
}

export function dominantArchetype(scores) {
  return Object.entries(scores).sort((a, b) => b[1] - a[1])[0][0]
}

// ─── Previously used domains ────────────────────────────────────────────────

function usedDomains(scenarios) {
  return scenarios.map(s => s.domain).filter(Boolean)
}

// ─── Main generator ─────────────────────────────────────────────────────────

/**
 * Generate the next scenario.
 *
 * @param {object} opts
 * @param {string}   opts.sessionId
 * @param {object}   opts.profile       — full profile object
 * @param {object[]} opts.priorScenarios — scenarios shown so far (may be empty)
 * @param {object[]} opts.priorAnswers   — answers to priorScenarios (same length)
 * @param {number}   opts.questionIndex  — 0-based index of the scenario to generate
 * @returns {{ scenario: object, usage: object }}
 */
export async function generateNextScenario({ sessionId, profile, priorScenarios, priorAnswers, questionIndex }) {
  const scores  = computeScores(priorAnswers)
  const top2    = topTwo(scores)
  const tied    = isTied(scores) && questionIndex >= DEFAULT_QUESTION_COUNT
  const strategyIndex = Math.min(questionIndex, STRATEGY.length - 1)
  const strategy = tied ? STRATEGY[Math.min(5 + (questionIndex - DEFAULT_QUESTION_COUNT), 6)] : STRATEGY[strategyIndex]

  const profileStr = profileToString(profile)
  const priorContext = priorScenarios.length === 0
    ? 'No prior scenarios shown yet.'
    : priorScenarios.map((s, i) => {
        const a = priorAnswers[i]
        return `Q${i + 1} [${s.domain}]: "${s.setup.slice(0, 80)}…"\n  → User chose: "${a?.label}" (value: ${a?.value})`
      }).join('\n\n')

  const scoreContext = priorAnswers.length === 0
    ? 'No scores yet — this is the first question.'
    : `Running archetype scores: ${JSON.stringify(scores)}\nTop archetypes: ${top2.join(' vs ')}`

  const system = `You generate scenario-based survey questions that probe how a person perceives AI.
Return ONLY a valid JSON object. No markdown, no backticks, no explanation.

Required shape:
{
  "domain":   "2-3 word domain label",
  "icon":     "single emoji",
  "setup":    "2-3 vivid, concrete sentences. Must be specific to this user's real context. No generalities.",
  "question": "One direct question, max 15 words.",
  "options": [
    { "label": "max 12 words, no period", "value": "tool|assist|partner|authority", "weight": { "tool|pragmatist|collaborator|delegator|transcendent": 1-3 } },
    { "label": "...", "value": "...", "weight": { ... } },
    { "label": "...", "value": "...", "weight": { ... } },
    { "label": "...", "value": "...", "weight": { ... } }
  ]
}

Option constraints:
- Exactly 4 options. One each anchoring to a different position on the tool→transcendent spectrum.
- All options must be genuinely defensible — no obviously correct answer.
- Labels must be first-person or direct action statements, not descriptions.
- Weight keys: tool, pragmatist, collaborator, delegator, transcendent. Values 1–3. Assign 2-3 weights per option.
- Do NOT repeat a domain from prior scenarios (see list below).

Scenario strategy for this question: ${strategy.instruction}`

  const userMessage = `User profile: ${profileStr}

Prior scenarios and answers:
${priorContext}

${scoreContext}

Previously used domains (do NOT repeat): ${usedDomains(priorScenarios).join(', ') || 'none'}

Generate scenario #${questionIndex + 1}.`

  const { data, usage } = await llmJSON({
    sessionId,
    callType: `generate_scenario_q${questionIndex}`,
    system,
    userMessage,
    maxTokens: 800,
  })

  // Validate shape
  if (!data.domain || !data.setup || !data.question || !Array.isArray(data.options) || data.options.length !== 4) {
    throw new Error(`Scenario Q${questionIndex} failed validation: ${JSON.stringify(data).slice(0, 200)}`)
  }

  return { scenario: data, usage }
}

// ─── Analysis generator ─────────────────────────────────────────────────────

/**
 * Generate the final 4-sentence personalized analysis.
 */
export async function generateAnalysis({ sessionId, profile, scenarios, answers }) {
  const scores  = computeScores(answers)
  const top     = dominantArchetype(scores)
  const archDef = ARCHETYPES[top]

  const profileStr = profileToString(profile)
  const scoreStr   = Object.entries(scores).map(([k, v]) => `${k}: ${v}`).join(', ')
  const choiceStr  = answers.map((a, i) =>
    `[Q${i+1} · ${scenarios[i]?.domain}] chose "${a.label}" (${a.value})`
  ).join('\n')

  const system = `You write objective, personalized AI-perception analyses based on scenario choices.
Write exactly 4 sentences. No bullets. No headers. Direct, non-judgmental, intellectually rigorous.
S1: Describe the user's revealed belief about AI in concrete terms, referencing their professional context and the ${archDef.label} archetype.
S2: Name the specific consistency or tension across their choices — cite 2 specific domains where their stance was most/least consistent.
S3: What this implies for how they will navigate AI in their actual work and life over the next 3–5 years.
S4: One falsifying condition — the specific development or event that would most likely shift their current stance.`

  const userMessage = `Profile: ${profileStr}
Archetype scores: ${scoreStr}
Dominant archetype: ${top} (${archDef.label})
Choices:\n${choiceStr}`

  const { text, usage } = await llmJSON({
    sessionId,
    callType: 'generate_analysis',
    system,
    userMessage,
    maxTokens: 600,
  }).catch(async () => {
    // Analysis doesn't need to be JSON — retry as plain text
    const { llmCall } = await import('./llm.js')
    return llmCall({ sessionId, callType: 'generate_analysis_fallback', system, userMessage, maxTokens: 600 })
  })

  return { analysis: text || '', archetype: top, scores, usage }
}
