/**
 * GCS Service
 * Bucket layout:
 *
 *  ai-survey-sessions/
 *    sessions/{sessionId}/profile.json
 *    sessions/{sessionId}/state.json          ← current question index + answer history
 *    sessions/{sessionId}/scenarios/{n}.json  ← each generated scenario (0-indexed)
 *    sessions/{sessionId}/complete.json       ← final result + archetype
 *
 *  ai-survey-xapi/
 *    statements/{YYYY-MM-DD}/{sessionId}/{statementId}.json
 *
 *  ai-survey-usage/
 *    usage/{YYYY-MM-DD}/{sessionId}/{callId}.json
 *    daily-totals/{YYYY-MM-DD}.json           ← aggregated daily cost
 *
 *  ai-survey-aggregates/
 *    archetypes/distribution.json             ← rolling aggregate
 *    archetypes/by-domain.json
 *    archetypes/by-region.json
 */

import { Storage } from '@google-cloud/storage'

const storage = new Storage({
  projectId: process.env.GCP_PROJECT_ID,
  // When running on Cloud Run with attached service account, no keyFile needed.
  // For local dev, set GOOGLE_APPLICATION_CREDENTIALS env var.
  ...(process.env.GCS_KEY_FILE ? { keyFilename: process.env.GCS_KEY_FILE } : {}),
})

const BUCKETS = {
  sessions:   process.env.GCS_BUCKET_SESSIONS   || 'ai-survey-sessions',
  xapi:       process.env.GCS_BUCKET_XAPI       || 'ai-survey-xapi',
  usage:      process.env.GCS_BUCKET_USAGE      || 'ai-survey-usage',
  aggregates: process.env.GCS_BUCKET_AGGREGATES || 'ai-survey-aggregates',
}

// ── Generic helpers ─────────────────────────────────────────────────────────

async function writeJSON(bucketName, key, data) {
  const bucket = storage.bucket(bucketName)
  const file   = bucket.file(key)
  await file.save(JSON.stringify(data, null, 2), {
    contentType: 'application/json',
    metadata: { cacheControl: 'no-cache' },
  })
}

async function readJSON(bucketName, key) {
  const bucket = storage.bucket(bucketName)
  const file   = bucket.file(key)
  const [content] = await file.download()
  return JSON.parse(content.toString())
}

async function exists(bucketName, key) {
  const [ex] = await storage.bucket(bucketName).file(key).exists()
  return ex
}

async function listKeys(bucketName, prefix) {
  const [files] = await storage.bucket(bucketName).getFiles({ prefix })
  return files.map(f => f.name)
}

// ── Session operations ──────────────────────────────────────────────────────

export async function saveProfile(sessionId, profile) {
  await writeJSON(BUCKETS.sessions, `sessions/${sessionId}/profile.json`, {
    sessionId,
    profile,
    createdAt: new Date().toISOString(),
  })
}

export async function getProfile(sessionId) {
  return readJSON(BUCKETS.sessions, `sessions/${sessionId}/profile.json`)
}

export async function saveState(sessionId, state) {
  // state = { questionIndex, answers: [{scenarioId, value, label, weight, answeredAt}] }
  await writeJSON(BUCKETS.sessions, `sessions/${sessionId}/state.json`, {
    ...state,
    updatedAt: new Date().toISOString(),
  })
}

export async function getState(sessionId) {
  const key = `sessions/${sessionId}/state.json`
  if (!(await exists(BUCKETS.sessions, key))) {
    return { questionIndex: 0, answers: [] }
  }
  return readJSON(BUCKETS.sessions, key)
}

export async function saveScenario(sessionId, index, scenario) {
  await writeJSON(
    BUCKETS.sessions,
    `sessions/${sessionId}/scenarios/${index}.json`,
    { ...scenario, generatedAt: new Date().toISOString() }
  )
}

export async function getScenario(sessionId, index) {
  return readJSON(BUCKETS.sessions, `sessions/${sessionId}/scenarios/${index}.json`)
}

export async function saveResult(sessionId, result) {
  // result = { archetype, scores, aiAnalysis, completedAt }
  await writeJSON(BUCKETS.sessions, `sessions/${sessionId}/complete.json`, {
    sessionId,
    ...result,
    completedAt: new Date().toISOString(),
  })
}

export async function getResult(sessionId) {
  return readJSON(BUCKETS.sessions, `sessions/${sessionId}/complete.json`)
}

// ── xAPI operations ─────────────────────────────────────────────────────────

export async function saveXAPIStatement(statement) {
  const date = new Date().toISOString().slice(0, 10)
  const key  = `statements/${date}/${statement.context.extensions['https://w3id.org/xapi/survey/session']}/${statement.id}.json`
  await writeJSON(BUCKETS.xapi, key, statement)
}

export async function getSessionStatements(sessionId, date) {
  const prefix = `statements/${date}/${sessionId}/`
  const keys   = await listKeys(BUCKETS.xapi, prefix)
  return Promise.all(keys.map(k => readJSON(BUCKETS.xapi, k)))
}

// ── Usage / accounting operations ───────────────────────────────────────────

export async function saveUsageRecord(record) {
  // record = { sessionId, callId, model, call_type, prompt_tokens, completion_tokens, cost_usd, timestamp }
  const date = record.timestamp.slice(0, 10)
  const key  = `usage/${date}/${record.sessionId}/${record.callId}.json`
  await writeJSON(BUCKETS.usage, key, record)

  // Update daily total (read-modify-write — acceptable at low concurrency)
  const totalKey = `daily-totals/${date}.json`
  let totals = { date, total_calls: 0, total_prompt_tokens: 0, total_completion_tokens: 0, total_cost_usd: 0 }
  if (await exists(BUCKETS.usage, totalKey)) {
    totals = await readJSON(BUCKETS.usage, totalKey)
  }
  totals.total_calls            += 1
  totals.total_prompt_tokens    += record.prompt_tokens
  totals.total_completion_tokens+= record.completion_tokens
  totals.total_cost_usd         += record.cost_usd
  await writeJSON(BUCKETS.usage, totalKey, totals)
}

export async function getSessionUsage(sessionId) {
  // Scan today and yesterday (sessions can straddle midnight)
  const today     = new Date().toISOString().slice(0, 10)
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10)
  const allKeys   = [
    ...await listKeys(BUCKETS.usage, `usage/${today}/${sessionId}/`),
    ...await listKeys(BUCKETS.usage, `usage/${yesterday}/${sessionId}/`),
  ]
  return Promise.all(allKeys.map(k => readJSON(BUCKETS.usage, k)))
}

export async function getDailyUsage(date) {
  const key = `daily-totals/${date}.json`
  if (!(await exists(BUCKETS.usage, key))) return null
  return readJSON(BUCKETS.usage, key)
}

// ── Aggregate operations ─────────────────────────────────────────────────────

export async function updateAggregates(result, profile) {
  const archetypeKey = `archetypes/distribution.json`
  const domainKey    = `archetypes/by-domain.json`
  const regionKey    = `archetypes/by-region.json`

  async function bump(bucket, key, field) {
    let data = {}
    if (await exists(bucket, key)) data = await readJSON(bucket, key)
    data[field] = (data[field] || 0) + 1
    data._total  = (data._total  || 0) + 1
    await writeJSON(bucket, key, data)
  }

  await Promise.all([
    bump(BUCKETS.aggregates, archetypeKey, result.archetype),
    bump(BUCKETS.aggregates, domainKey,    `${profile.domain}:${result.archetype}`),
    bump(BUCKETS.aggregates, regionKey,    `${profile.region}:${result.archetype}`),
  ])
}

export async function getAggregates() {
  const [dist, byDomain, byRegion] = await Promise.all([
    readJSON(BUCKETS.aggregates, 'archetypes/distribution.json').catch(() => ({})),
    readJSON(BUCKETS.aggregates, 'archetypes/by-domain.json').catch(() => ({})),
    readJSON(BUCKETS.aggregates, 'archetypes/by-region.json').catch(() => ({})),
  ])
  return { distribution: dist, byDomain, byRegion }
}
