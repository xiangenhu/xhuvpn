/**
 * xAPI Service
 * Builds conformant xAPI 1.0.3 statements for all survey events.
 *
 * Statement types emitted:
 *   survey.initialized   — session started, profile submitted
 *   survey.experienced   — scenario presented to user
 *   survey.answered      — user selected an option
 *   survey.completed     — all scenarios answered, archetype computed
 *   survey.llm_called    — LLM invocation (for audit/accounting)
 */

import { v4 as uuidv4 } from 'uuid'
import { saveXAPIStatement } from './gcs.js'

// xAPI Activity IDs (IRIs)
const IRI = {
  survey:    'https://aiperception.survey/activity/survey',
  scenario:  'https://aiperception.survey/activity/scenario',
  profile:   'https://aiperception.survey/activity/profile',
  llmCall:   'https://aiperception.survey/activity/llm-call',
  extension: {
    session:   'https://w3id.org/xapi/survey/session',
    profile:   'https://aiperception.survey/extensions/profile',
    scenario:  'https://aiperception.survey/extensions/scenario',
    answer:    'https://aiperception.survey/extensions/answer',
    scores:    'https://aiperception.survey/extensions/archetype-scores',
    llmUsage:  'https://aiperception.survey/extensions/llm-usage',
  },
}

const VERBS = {
  initialized: { id: 'http://adlnet.gov/expapi/verbs/initialized',    display: { 'en-US': 'initialized' } },
  experienced: { id: 'http://adlnet.gov/expapi/verbs/experienced',    display: { 'en-US': 'experienced' } },
  answered:    { id: 'http://adlnet.gov/expapi/verbs/answered',       display: { 'en-US': 'answered'    } },
  completed:   { id: 'http://adlnet.gov/expapi/verbs/completed',      display: { 'en-US': 'completed'   } },
  interacted:  { id: 'http://adlnet.gov/expapi/verbs/interacted',     display: { 'en-US': 'interacted'  } },
}

function makeActor(sessionId) {
  // Anonymous actor — identified by session only (no PII)
  return {
    objectType: 'Agent',
    account: {
      homePage: 'https://aiperception.survey',
      name: sessionId,
    },
  }
}

function makeContext(sessionId, extra = {}) {
  return {
    platform: 'AI Perception Survey v0.2',
    extensions: {
      [IRI.extension.session]: sessionId,
      ...extra,
    },
  }
}

function baseStatement(sessionId, verb, object, result = undefined, contextExtra = {}) {
  return {
    id:        uuidv4(),
    actor:     makeActor(sessionId),
    verb,
    object,
    timestamp: new Date().toISOString(),
    version:   '1.0.3',
    context:   makeContext(sessionId, contextExtra),
    ...(result ? { result } : {}),
  }
}

// ── Statement factories ─────────────────────────────────────────────────────

/**
 * Emitted when the user submits their profile and a session is created.
 */
export function stmtInitialized(sessionId, profile) {
  return baseStatement(
    sessionId,
    VERBS.initialized,
    { objectType: 'Activity', id: IRI.survey, definition: { name: { 'en-US': 'AI Perception Survey' }, type: IRI.survey } },
    undefined,
    { [IRI.extension.profile]: profile }
  )
}

/**
 * Emitted each time a scenario is presented to the user.
 */
export function stmtScenarioViewed(sessionId, scenario, questionIndex) {
  return baseStatement(
    sessionId,
    VERBS.experienced,
    {
      objectType: 'Activity',
      id: `${IRI.scenario}/${sessionId}/${questionIndex}`,
      definition: {
        name:        { 'en-US': `Scenario ${questionIndex + 1}: ${scenario.domain}` },
        description: { 'en-US': scenario.setup },
        type:        IRI.scenario,
      },
    },
    undefined,
    {
      [IRI.extension.scenario]: {
        index:    questionIndex,
        domain:   scenario.domain,
        icon:     scenario.icon,
        question: scenario.question,
      },
    }
  )
}

/**
 * Emitted when the user selects an option and clicks Next.
 */
export function stmtAnswered(sessionId, scenario, questionIndex, answer, timeOnQuestionMs) {
  return baseStatement(
    sessionId,
    VERBS.answered,
    {
      objectType: 'Activity',
      id: `${IRI.scenario}/${sessionId}/${questionIndex}`,
      definition: { name: { 'en-US': `Scenario ${questionIndex + 1}: ${scenario.domain}` }, type: IRI.scenario },
    },
    {
      response:  answer.value,
      duration:  msToISO8601Duration(timeOnQuestionMs),
      extensions: {
        [IRI.extension.answer]: {
          label:  answer.label,
          value:  answer.value,
          weight: answer.weight,
        },
      },
    }
  )
}

/**
 * Emitted when the survey is fully completed.
 */
export function stmtCompleted(sessionId, archetype, scores, aiAnalysis, totalDurationMs) {
  return baseStatement(
    sessionId,
    VERBS.completed,
    { objectType: 'Activity', id: IRI.survey, definition: { name: { 'en-US': 'AI Perception Survey' }, type: IRI.survey } },
    {
      completion: true,
      duration:   msToISO8601Duration(totalDurationMs),
      extensions: {
        [IRI.extension.scores]: scores,
        'https://aiperception.survey/extensions/archetype': archetype,
        'https://aiperception.survey/extensions/analysis':  aiAnalysis,
      },
    }
  )
}

/**
 * Emitted for every LLM API call — supports billing audit.
 */
export function stmtLLMCall(sessionId, usageRecord) {
  return baseStatement(
    sessionId,
    VERBS.interacted,
    {
      objectType: 'Activity',
      id: `${IRI.llmCall}/${usageRecord.callId}`,
      definition: { name: { 'en-US': `LLM Call: ${usageRecord.callType}` }, type: IRI.llmCall },
    },
    {
      extensions: {
        [IRI.extension.llmUsage]: {
          callId:            usageRecord.callId,
          callType:          usageRecord.callType,
          model:             usageRecord.model,
          prompt_tokens:     usageRecord.prompt_tokens,
          completion_tokens: usageRecord.completion_tokens,
          cost_usd:          usageRecord.cost_usd,
        },
      },
    }
  )
}

// ── Persist + return ────────────────────────────────────────────────────────

/**
 * Persist a statement to GCS and return it.
 * All route handlers call this — do not call saveXAPIStatement directly.
 */
export async function emit(statement) {
  await saveXAPIStatement(statement)
  return statement
}

// ── Helpers ─────────────────────────────────────────────────────────────────

function msToISO8601Duration(ms) {
  const totalSec = Math.floor(ms / 1000)
  const h = Math.floor(totalSec / 3600)
  const m = Math.floor((totalSec % 3600) / 60)
  const s = totalSec % 60
  return `PT${h > 0 ? h + 'H' : ''}${m > 0 ? m + 'M' : ''}${s}S`
}
