/**
 * LLM Service
 * Wraps Anthropic SDK. Every call:
 *   1. Executes the API request
 *   2. Extracts usage (input/output tokens)
 *   3. Computes estimated cost
 *   4. Writes a usage record to GCS
 *   5. Returns { text, usage }
 */

import Anthropic from '@anthropic-ai/sdk'
import { v4 as uuidv4 } from 'uuid'
import { saveUsageRecord } from './gcs.js'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

// Pricing table (USD per million tokens) — update when Anthropic changes pricing
const PRICING = {
  'claude-sonnet-4-20250514': { input: 3.00,  output: 15.00  },
  'claude-opus-4-20250514':   { input: 15.00, output: 75.00  },
  'claude-haiku-4-5-20251001':{ input: 0.80,  output: 4.00   },
}

const DEFAULT_MODEL = process.env.LLM_MODEL || 'claude-sonnet-4-20250514'

/**
 * Core call — all other functions go through here.
 * @param {object} opts
 * @param {string}   opts.sessionId
 * @param {string}   opts.callType       e.g. 'generate_scenario', 'generate_analysis'
 * @param {string}   opts.system
 * @param {string}   opts.userMessage
 * @param {number}  [opts.maxTokens]
 * @param {string}  [opts.model]
 * @returns {{ text: string, usage: object }}
 */
export async function llmCall({ sessionId, callType, system, userMessage, maxTokens = 1200, model = DEFAULT_MODEL }) {
  const callId    = uuidv4()
  const timestamp = new Date().toISOString()

  const message = await client.messages.create({
    model,
    max_tokens: maxTokens,
    system,
    messages: [{ role: 'user', content: userMessage }],
  })

  const text             = message.content.find(b => b.type === 'text')?.text || ''
  const prompt_tokens    = message.usage.input_tokens
  const completion_tokens= message.usage.output_tokens
  const price            = PRICING[model] || PRICING[DEFAULT_MODEL]
  const cost_usd         = (prompt_tokens / 1_000_000) * price.input
                         + (completion_tokens / 1_000_000) * price.output

  const usageRecord = {
    callId,
    sessionId,
    callType,
    model,
    prompt_tokens,
    completion_tokens,
    cost_usd: parseFloat(cost_usd.toFixed(8)),
    stop_reason: message.stop_reason,
    timestamp,
  }

  // Fire-and-forget — don't block the response on accounting write
  saveUsageRecord(usageRecord).catch(err =>
    console.error('[LLM] Usage record write failed:', err.message)
  )

  return { text, usage: usageRecord }
}

/**
 * Convenience: parse JSON from LLM response, with retry on parse failure.
 * @param {object} opts  Same as llmCall, plus opts.schema (optional Zod schema)
 */
export async function llmJSON(opts) {
  const { text, usage } = await llmCall({ ...opts, maxTokens: opts.maxTokens || 1500 })
  try {
    const cleaned = text.trim().replace(/^```json\s*/i, '').replace(/```\s*$/, '')
    return { data: JSON.parse(cleaned), usage }
  } catch (err) {
    console.error('[LLM] JSON parse failed. Raw text:', text.slice(0, 300))
    throw new Error(`LLM returned non-JSON for callType=${opts.callType}: ${err.message}`)
  }
}
