/**
 * Express server
 * - Serves the React frontend from /frontend/dist (production)
 * - Mounts all API routes under /api
 * - Cloud Run: listens on PORT env (default 8080)
 */

import express        from 'express'
import compression    from 'compression'
import helmet         from 'helmet'
import cors           from 'cors'
import morgan         from 'morgan'
import rateLimit      from 'express-rate-limit'
import { fileURLToPath } from 'url'
import path           from 'path'

import { sessionRouter } from './routes/sessions.js'
import { surveyRouter }  from './routes/survey.js'
import { adminRouter }   from './routes/admin.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const app  = express()
const PORT = process.env.PORT || 8080

// ── Middleware ───────────────────────────────────────────────────────────────
app.use(compression())
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc:  ["'self'", "'unsafe-inline'"],   // Vite inlines scripts in dev
      styleSrc:   ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc:    ["'self'", 'https://fonts.gstatic.com'],
      connectSrc: ["'self'"],                       // API calls go to same origin
    },
  },
}))
app.use(cors({ origin: process.env.CORS_ORIGIN || false }))
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'))
app.use(express.json({ limit: '64kb' }))

// ── Rate limiting ────────────────────────────────────────────────────────────
const apiLimiter = rateLimit({
  windowMs:         60 * 1000,   // 1 minute
  max:              60,           // 60 req / min per IP
  standardHeaders:  true,
  legacyHeaders:    false,
  message:          { error: 'Too many requests — please slow down' },
})
const sessionLimiter = rateLimit({
  windowMs:   10 * 60 * 1000,  // 10 minutes
  max:        5,                // 5 sessions per IP per 10 min (prevent abuse)
  message:    { error: 'Too many sessions created — please wait' },
})

// ── API Routes ───────────────────────────────────────────────────────────────
app.use('/api',              apiLimiter)
app.use('/api/sessions',     sessionLimiter, sessionRouter)
app.use('/api/survey',       surveyRouter)
app.use('/api/admin',        adminRouter)

// ── Health check (Cloud Run requirement) ─────────────────────────────────────
app.get('/health', (_, res) => res.json({ status: 'ok', ts: new Date().toISOString() }))

// ── Serve frontend (production) ───────────────────────────────────────────────
const frontendDist = path.join(__dirname, '../frontend/dist')
app.use(express.static(frontendDist))
app.get('*', (_, res) => res.sendFile(path.join(frontendDist, 'index.html')))

// ── Error handler ─────────────────────────────────────────────────────────────
app.use((err, req, res, _next) => {
  console.error('[unhandled]', err)
  res.status(500).json({ error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message })
})

app.listen(PORT, () => {
  console.log(`[server] Listening on port ${PORT}`)
  console.log(`[server] NODE_ENV=${process.env.NODE_ENV || 'development'}`)
  console.log(`[server] GCP_PROJECT=${process.env.GCP_PROJECT_ID || '(not set)'}`)
})
