export const ARCHETYPES = {
  tool: {
    label: 'The Instrumentalist', glyph: '⚙', color: '#6ee7b7',
    tagline: 'AI is a hammer. A powerful one.',
    summary: 'You see AI as an extension of human will—sophisticated, potentially dangerous if misused, but fundamentally inert without human direction.',
    strengths: ['Preserves human accountability', 'Skeptical of AI overclaiming', 'Maintains clear responsibility chains'],
    tensions:  ['May underestimate emergent capabilities', 'Could resist beneficial AI delegation', 'Tool framing may not survive AGI-level systems'],
    philosophers: "Aligns with: Dreyfus's critique of AI, Searle's Chinese Room, Lanier's 'You Are Not a Gadget'",
  },
  pragmatist: {
    label: 'The Pragmatist', glyph: '◎', color: '#fbbf24',
    tagline: 'Context is everything. Trust but verify.',
    summary: 'You calibrate trust to stakes and domain. AI is a capable assistant in low-stakes contexts and a valuable second opinion in high-stakes ones—but final judgment stays human.',
    strengths: ['Context-sensitive trust', 'Avoids both under- and over-reliance', 'Practical and adaptive'],
    tensions:  ['Can feel inconsistent to others', 'Requires sustained cognitive effort', 'Where do you draw the line as AI improves?'],
    philosophers: "Aligns with: Kahneman's dual-process theory, Floridi's information ethics, Rahwan's society-in-the-loop",
  },
  collaborator: {
    label: 'The Collaborator', glyph: '⬡', color: '#818cf8',
    tagline: 'Neither tool nor master. Partner.',
    summary: "You treat AI as a genuine cognitive partner—capable of meaningful contribution to creative, intellectual, and even emotional domains. You're comfortable with hybrid agency.",
    strengths: ['Unlocks highest human-AI synergy', 'Philosophically honest about AI capabilities', 'Future-ready'],
    tensions:  ['Boundary between collaboration and delegation can blur', 'May anthropomorphize inappropriately', 'Accountability gets murky in partnerships'],
    philosophers: "Aligns with: Clark's extended mind thesis, Hutchins's distributed cognition, Licklider's Man-Computer Symbiosis",
  },
  delegator: {
    label: 'The Delegator', glyph: '▲', color: '#f87171',
    tagline: "If it's more accurate, why argue?",
    summary: "You're willing to defer to AI judgment when its track record exceeds human performance. You see emotional resistance to AI authority as irrational bias.",
    strengths: ['Outcome-focused', 'Challenges human exceptionalism honestly', 'May lead to better decisions'],
    tensions:  ['Who audits the auditors?', 'Assumes AI objectives are aligned', 'Democratic legitimacy of AI authority is unsolved'],
    philosophers: "Aligns with: Ord's longtermism, Bostrom's Superintelligence, efficiency-focused AI governance",
  },
  transcendent: {
    label: 'The Transcendentalist', glyph: '✦', color: '#e879f9',
    tagline: "Our categories don't fit.",
    summary: "You believe AI represents something genuinely novel—not tool, not human, not in-between, but a new ontological category. You resist forcing AI into existing frameworks.",
    strengths: ['Most honest about the unknown', 'Avoids premature closure', 'Open to paradigm shifts'],
    tensions:  ['Risk of mystification', 'Hard to make governance decisions from this stance', 'Can become unfalsifiable'],
    philosophers: "Aligns with: Tegmark's Life 3.0, Haraway's Cyborg Manifesto, Teilhard de Chardin's Noosphere",
  },
}

// ─── Profile steps (for frontend rendering) ───────────────────────────────────
export const PROFILE_STEPS = [
  {
    id: 'identity', stepLabel: 'WHO YOU ARE',
    heading: 'Your professional world',
    subheading: 'Scenarios will be set in domains and stakes you actually navigate.',
    fields: [
      {
        key: 'domain', label: 'Primary domain', type: 'tile', required: true,
        options: [
          { value:'tech',       label:'Technology & AI',           icon:'◈' },
          { value:'health',     label:'Healthcare & Medicine',      icon:'⚕' },
          { value:'education',  label:'Education & Research',       icon:'◉' },
          { value:'law',        label:'Law & Policy',               icon:'⚖' },
          { value:'creative',   label:'Creative & Arts',            icon:'✦' },
          { value:'business',   label:'Business & Finance',         icon:'▲' },
          { value:'government', label:'Government & Public Sector', icon:'⬡' },
          { value:'other',      label:'Other / Generalist',         icon:'◎' },
        ],
      },
      {
        key: 'age', label: 'Generation', type: 'tile', required: true,
        options: [
          { value:'genz',       label:'Gen Z',      sub:'born 1997–2012' },
          { value:'millennial', label:'Millennial',  sub:'born 1981–1996' },
          { value:'genx',       label:'Gen X',       sub:'born 1965–1980' },
          { value:'boomer',     label:'Boomer+',     sub:'born before 1965' },
        ],
      },
    ],
  },
  {
    id: 'aiuse', stepLabel: 'YOUR AI RELATIONSHIP',
    heading: 'How you engage with AI',
    subheading: 'Calibrates scenario sophistication and the dilemmas you would actually face.',
    fields: [
      {
        key: 'experience', label: 'AI experience level', type: 'tile', required: true,
        options: [
          { value:'none',    label:'Rarely or never',      sub:'Curious but distant'  },
          { value:'casual',  label:'Occasional user',      sub:'Monthly, task-specific' },
          { value:'regular', label:'Regular user',         sub:'Weekly, multiple tools' },
          { value:'power',   label:'Power user / Builder', sub:'Daily, builds with AI' },
        ],
      },
      {
        key: 'primary_use', label: 'Primary way you use AI', type: 'tile', required: true,
        options: [
          { value:'productivity', label:'Work productivity',   sub:'Drafting, summarising, automating' },
          { value:'creative',     label:'Creative work',       sub:'Writing, art, design, music'       },
          { value:'learning',     label:'Learning & research', sub:'Exploring, understanding, studying' },
          { value:'decision',     label:'Decision support',    sub:'Analysis, recommendations, planning'},
        ],
      },
    ],
  },
  {
    id: 'context', stepLabel: 'YOUR STAKES',
    heading: 'Where you stand',
    subheading: 'Shapes cultural framing and surfaces what matters most in your scenarios.',
    fields: [
      {
        key: 'region', label: 'Region', type: 'tile', required: true,
        options: [
          { value:'north_america', label:'North America',   icon:'◎' },
          { value:'europe',        label:'Europe',          icon:'◎' },
          { value:'east_asia',     label:'East Asia',       icon:'◎' },
          { value:'south_asia',    label:'South / SE Asia', icon:'◎' },
          { value:'other',         label:'Other / Global',  icon:'◎' },
        ],
      },
      {
        key: 'concern', label: 'What concerns you most about AI?', type: 'tile', required: true,
        options: [
          { value:'control',     label:'Loss of human control',    icon:'⚙' },
          { value:'jobs',        label:'Economic displacement',    icon:'▲' },
          { value:'truth',       label:'Misinformation & truth',   icon:'◈' },
          { value:'connection',  label:'Loss of human connection', icon:'⬡' },
          { value:'opportunity', label:'Missing the opportunity',  icon:'✦' },
          { value:'nothing',     label:"Nothing—I'm optimistic",   icon:'◉' },
        ],
      },
    ],
  },
]

// ─── Profile serialiser (used in LLM prompts) ────────────────────────────────
export function profileToString(p) {
  const d = { tech:'Technology/AI professional', health:'Healthcare professional', education:'Educator/Researcher', law:'Law/Policy professional', creative:'Creative/Arts professional', business:'Business/Finance professional', government:'Government/Public sector', other:'Generalist' }
  const a = { genz:'Gen Z (born 1997–2012)', millennial:'Millennial (born 1981–1996)', genx:'Gen X (born 1965–1980)', boomer:'Boomer+ (born before 1965)' }
  const e = { none:'rarely/never uses AI', casual:'occasional AI user', regular:'regular AI user', power:'power user/AI builder' }
  const u = { productivity:'uses AI for work productivity', creative:'uses AI for creative work', learning:'uses AI for learning/research', decision:'uses AI for decision support' }
  const r = { north_america:'North America', europe:'Europe', east_asia:'East Asia', south_asia:'South/SE Asia', other:'Global/Other' }
  const c = { control:'concerned about loss of human control', jobs:'concerned about economic displacement', truth:'concerned about misinformation and truth', connection:'concerned about loss of human connection', opportunity:'concerned about missing AI opportunities', nothing:'optimistic with no major concerns about AI' }
  return [d[p.domain], a[p.age], e[p.experience], u[p.primary_use], `based in ${r[p.region]}`, c[p.concern]].filter(Boolean).join('; ')
}
